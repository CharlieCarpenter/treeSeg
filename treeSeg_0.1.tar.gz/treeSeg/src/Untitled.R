
devtools::install_github("CharlieCarpenter/treeSeg", subdir = 'TreeSeg')
library(FactoMineR); library(factoextra); library(treeSeg)

## Data generation
p <- 30; n <- 150

set.seed(24)
graph <- sample_grg(p, 0.25); plot(graph, layout = layout_with_kk)

## 3 groups
data <- data.frame(X1 = factor(rbinom(n, 2, 0.5)))
b0 <- c(0,2,4); zz <- rep(c(0,2,4),each=10)
sd.y <- 1.5

## Converts a graph into an adjacency matrix
adj <- as.matrix( get.adjacency(graph) )

## Convert adjacency matrix into a "starter" precision matrix
test <- adj + diag(p)

## Make test positive using approach of Danaher et al (2014)
## Function in SimulationFuncitons.R
Omega1 <- Danaher_pos_def(test)
pd <- is.positive.definite(Omega1)

## Outcome and model.matrix
# mX <- model.matrix(~ X1, data = data)
Z <- mvrnorm(n=nrow(mX), rep(0,p), solve(Omega1))
Y <- rnorm(n=nrow(mX), mX%*%b0+Z%*%zz, sd.y)

plot(Y)



lZ <- scale(Z)
if(rho == "median.pairwise") rho <- median(dist(Z))

# no network information
# ZL <- Z %*% K_regL

if(kernel == "G") K <- Gaussian_kernel(rho, Z)
if(kernel == "L") K <- plyKern(Z, pow = 1, rho = 0)

dd <- cbind(Y, data)
dav_pval <- SKAT.c(H0.form, data = dd, K=K)$Qq


